import React from 'react';

export default function tree() {
  return (
    <div className='flex w-screen overflow-x-scroll'>
      <div>hello</div>
    </div>
  )
}
