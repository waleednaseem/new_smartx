import React from "react";
import Sidebaradmin from "../src/components/adminDB/Sidebaradmin";

export default function adminDB() {
  return (
    <div>
      adminDB


    </div>
  );
}
