import {combineReducers} from 'redux';
import auth from './auth';

// In this file we will combine all the reducers

export default combineReducers({
  auth,
});
