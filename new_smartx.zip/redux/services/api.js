
var apiUrl = 'https://api.smartxblockchain.com';

export default apiUrl;
